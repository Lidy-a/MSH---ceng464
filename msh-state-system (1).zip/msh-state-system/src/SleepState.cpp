#include "SleepState.h"

void SleepState::applySettings() {
    std::cout << "Applying Sleep state settings...\n";
    // Power off devices or reduce their activity
}
