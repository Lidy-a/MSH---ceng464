#include "NormalState.h"

void NormalState::applySettings() {
    std::cout << "Applying Normal state settings...\n";
    // Add device settings, power states, etc. for Normal state
}
