#include "HighPerformanceState.h"

void HighPerformanceState::applySettings() {
    std::cout << "Applying High Performance state settings...\n";
    // Add logic for high performance settings (e.g., boost CPU, turn on high-power mode)
}
