# msh-state-system
State machine module for My Sweet Home (MSH) project
