# msh-detectors-security
Detectors &amp; Security System module for My Sweet Home (MSH)
## Detectors & Security System Module

This module implements the detector and security functionality
of the My Sweet Home (MSH) project.

### Responsibilities
- Smoke and gas detection
- Alarm activation
- Light activation during threats
- Emergency service notification

### Design Patterns
- Observer Pattern for detection events
- Chain of Responsibility for alarm workflow

### Author
Balla Simpara
