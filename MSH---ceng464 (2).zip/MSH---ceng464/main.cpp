#include "core/MSHSystem.h"

int main() {
    MSHSystem system;
    system.run();
    return 0;
}
