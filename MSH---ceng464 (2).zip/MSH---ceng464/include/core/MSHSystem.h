#ifndef MSHSYSTEM_H
#define MSHSYSTEM_H

class MSHSystem {
public:
    void run();   // main loop entry point
};

#endif
