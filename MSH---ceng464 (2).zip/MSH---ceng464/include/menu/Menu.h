#ifndef MENU_H
#define MENU_H

class Menu {
public:
    void show() const;
};

#endif
